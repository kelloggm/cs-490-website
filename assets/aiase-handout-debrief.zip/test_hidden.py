"""Hidden tests for the spreadsheet engine described in spec.md.

Run with:  python3 -m unittest test_hidden
"""

import math
import unittest

from sheet import Sheet


class Base(unittest.TestCase):

    def setUp(self):
        self.s = Sheet()

    def put(self, **cells):
        for name, text in cells.items():
            self.s.set(name, text)

    def assertNumber(self, actual, expected):
        """Check that `actual` is a number close to `expected` (see R3)."""
        self.assertNotIsInstance(actual, (str, type(None)),
                                 f"expected a number, got {actual!r}")
        self.assertTrue(
            math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-9),
            f"expected {expected!r}, got {actual!r}")

    def assertValue(self, cell, expected):
        actual = self.s.get(cell)
        if isinstance(expected, str) or expected is None:
            self.assertEqual(actual, expected)
        else:
            self.assertNumber(actual, expected)


# =====================================================================
# Group A: rules where the spec deliberately differs from spreadsheets
# =====================================================================

class GroupA_R5_Power(Base):

    def test_R5_unary_minus_before_power(self):
        self.put(A1="=-2^2", A2="=--2^2", A3="=(-2)^2")
        self.assertValue("A1", -4)
        self.assertValue("A2", 4)
        self.assertValue("A3", 4)

    def test_R5_power_groups_right_to_left(self):
        self.put(A1="=2^3^2", A2="=(2^3)^2", A3="=2^1^3^2")
        self.assertValue("A1", 512)
        self.assertValue("A2", 64)
        self.assertValue("A3", 2)  # 2^(1^9)

    def test_R5_right_operand_may_start_with_minus(self):
        self.put(A1="=2^-1", A2="=2^-2^2", A3="=-2^-2")
        self.assertValue("A1", 0.5)
        self.assertValue("A2", 0.0625)  # 2^(-(2^2))
        self.assertValue("A3", -0.25)

    def test_R5_unary_minus_on_power_of_cell_reference(self):
        self.put(A1="3", B1="-3", C1="=-A1^2", C2="=-B1^2", C3="=-(B1)^2")
        self.assertValue("C1", -9)
        self.assertValue("C2", -9)
        self.assertValue("C3", -9)

    def test_R5_minus_power_inside_larger_expressions(self):
        self.put(A1="=10-2^2", A2="=3*-2^2", A3="=1+2^-1*4", A4="=10+-3^2")
        self.assertValue("A1", 6)
        self.assertValue("A2", -12)
        self.assertValue("A3", 3)
        self.assertValue("A4", 1)

    def test_R5_minus_power_with_parentheses(self):
        self.put(A1="=-(2^2)", A2="=(-2)^3", A3="=-(1+1)^(1+1)",
                 A4="=2^(-1+3)")
        self.assertValue("A1", -4)
        self.assertValue("A2", -8)
        self.assertValue("A3", -4)
        self.assertValue("A4", 4)

    def test_R5_minus_binds_looser_so_no_num_error(self):
        # -8^(1/3) is -(8^(1/3)); only (-8)^(1/3) is a negative base.
        self.put(A1="=-8^(1/3)", A2="=(-8)^(1/3)", B1="4", A3="=-B1^0.5")
        self.assertValue("A1", -2)
        self.assertValue("A2", "#NUM!")
        self.assertValue("A3", -2)


class GroupA_R9_Cycles(Base):

    def test_R9_self_reference(self):
        self.put(A1="=A1", B1="=B1+1", C1="=SUM(C1, 5)")
        self.assertValue("A1", "#CYCLE!")
        self.assertValue("B1", "#CYCLE!")
        self.assertValue("C1", "#CYCLE!")

    def test_R9_two_and_three_cell_cycles(self):
        self.put(A1="=B1+1", B1="=A1*2",
                 C1="=D1", D1="=E1", E1="=C1")
        for c in ("A1", "B1", "C1", "D1", "E1"):
            self.assertValue(c, "#CYCLE!")

    def test_R9_cells_depending_on_cycle_directly_and_indirectly(self):
        self.put(A1="=B1", B1="=A1",
                 C1="=A1*2", D1="=C1+1", E1="=MAX(D1:D1, 7)")
        self.assertValue("C1", "#CYCLE!")
        self.assertValue("D1", "#CYCLE!")
        self.assertValue("E1", "#CYCLE!")

    def test_R9_cell_a_cycle_depends_on_is_not_in_cycle(self):
        self.put(A1="=B1", B1="=A1+C1", C1="5", D1="=C1*2")
        self.assertValue("A1", "#CYCLE!")
        self.assertValue("C1", 5)
        self.assertValue("D1", 10)

    def test_R9_cycle_through_range(self):
        self.put(E1="=SUM(E2:E5)", E2="1", E4="=E1+1", F1="=AVERAGE(E1:E2)")
        self.assertValue("E1", "#CYCLE!")
        self.assertValue("E4", "#CYCLE!")
        self.assertValue("F1", "#CYCLE!")

    def test_R9_range_containing_itself_with_all_else_empty(self):
        # Every other cell in the range is empty, yet B2 depends on itself.
        self.put(B2="=MAX(A1:C3)", D1="=AVERAGE(D1)", D2="=SUM(D9:D2)")
        self.assertValue("B2", "#CYCLE!")
        self.assertValue("D1", "#CYCLE!")
        self.assertValue("D2", "#CYCLE!")

    def test_R9_dependency_through_range_on_cycle_cell(self):
        self.put(A1="=B1", B1="=A1", C1="=SUM(A1:A3)", D1="=MIN(C3:C1)")
        self.assertValue("C1", "#CYCLE!")
        self.assertValue("D1", "#CYCLE!")

    def test_R9_cycle_overrides_other_errors(self):
        self.put(A1="=B1", B1="=A1", Z1="oops",
                 C1="=Z1+A1", C2="=SUM(1/0, A1)", C3="=10^400-A1")
        self.assertValue("C1", "#CYCLE!")
        self.assertValue("C2", "#CYCLE!")
        self.assertValue("C3", "#CYCLE!")

    def test_R9_cycle_member_containing_error_is_cycle(self):
        self.put(A1="=1/0+B1", B1="=A1", C1="=Z1", Z1="=C1+0^-1")
        self.assertValue("A1", "#CYCLE!")
        self.assertValue("B1", "#CYCLE!")
        self.assertValue("C1", "#CYCLE!")
        self.assertValue("Z1", "#CYCLE!")

    def test_R9_syntax_error_cell_references_nothing(self):
        self.put(A1="=B1+", B1="=A1", C1="=SUM(C1", D1="=D1 D1")
        self.assertValue("A1", "#SYNTAX!")
        self.assertValue("B1", "#SYNTAX!")
        self.assertValue("C1", "#SYNTAX!")
        self.assertValue("D1", "#SYNTAX!")

    def test_R9_syntax_error_mentioning_cycle_cell_stays_syntax(self):
        self.put(A1="=B1", B1="=A1", C1="=A1+*2")
        self.assertValue("C1", "#SYNTAX!")

    def test_R9_R10_change_creates_then_breaks_cycle(self):
        self.put(A1="=B1+1", B1="2", C1="=A1")
        self.assertValue("A1", 3)
        self.s.set("B1", "=A1*2")
        self.assertValue("A1", "#CYCLE!")
        self.assertValue("B1", "#CYCLE!")
        self.assertValue("C1", "#CYCLE!")
        self.s.set("B1", "7")
        self.assertValue("A1", 8)
        self.assertValue("C1", 8)

    def test_R9_R10_clearing_breaks_cycle(self):
        self.put(A1="=B1", B1="=A1")
        self.assertValue("A1", "#CYCLE!")
        self.s.set("B1", "")
        self.assertValue("B1", None)
        self.assertValue("A1", 0)

    def test_R9_R10_shrinking_range_breaks_cycle(self):
        self.put(E1="=SUM(E2:E5)", E3="=E1", E5="4")
        self.assertValue("E3", "#CYCLE!")
        self.s.set("E1", "=SUM(E4:E5)")
        self.assertValue("E1", 4)
        self.assertValue("E3", 4)


# =====================================================================
# Group B: harder cases of the other rules
# =====================================================================

class GroupB_R8_ErrorOrder(Base):

    def test_R8_left_error_wins_over_higher_precedence_right(self):
        self.put(A1="=1/0", A2="=(-1)^0.5",
                 B1="=A1-10^400", B2="=A2+0^-1", B3="=10^400-2*(1/0)")
        self.assertValue("B1", "#DIV/0!")
        self.assertValue("B2", "#NUM!")
        self.assertValue("B3", "#NUM!")

    def test_R8_right_error_when_left_is_fine_despite_precedence(self):
        self.put(Z1="x", B1="=1+2*Z1", B2="=2^Z1^(1/0)")
        self.assertValue("B1", "#VALUE!")
        self.assertValue("B2", "#VALUE!")

    def test_R8_operand_error_beats_operator_error(self):
        self.put(Z1="x", B1="=Z1/0", B2="=(10^400)/0", B3="=-Z1")
        self.assertValue("B1", "#VALUE!")
        self.assertValue("B2", "#NUM!")
        self.assertValue("B3", "#VALUE!")

    def test_R8_function_arguments_left_to_right(self):
        self.put(Z1="x", B1="=SUM(1/0, Z1)", B2="=MAX(Z1, 1/0)",
                 B3="=AVERAGE(1, 10^400, Z1)")
        self.assertValue("B1", "#DIV/0!")
        self.assertValue("B2", "#VALUE!")
        self.assertValue("B3", "#NUM!")

    def test_R8_range_cells_row_by_row(self):
        # Row by row: B1, C1, B2, C2 -> C1 (#VALUE!) is found before B2.
        self.put(C1="x", B2="=1/0",
                 D1="=SUM(B1:C2)", D2="=SUM(C2:B1)", D3="=MIN(B2:C1)")
        self.assertValue("D1", "#VALUE!")
        self.assertValue("D2", "#VALUE!")
        self.assertValue("D3", "#VALUE!")

    def test_R8_syntax_error_propagates_through_reference_and_range(self):
        self.put(A2="=1+", B1="=A2*2", B2="=SUM(A1:A3)", B3="=B1+1/0")
        self.assertValue("B1", "#SYNTAX!")
        self.assertValue("B2", "#SYNTAX!")
        self.assertValue("B3", "#SYNTAX!")


class GroupB_R5_R8_NumAndDiv(Base):

    def test_R5_zero_to_zero_and_zero_to_negative(self):
        self.put(A1="=0^0", A2="=0^-1", A3="=0^-0.5", A4="=B9^0")
        self.assertValue("A1", 1)
        self.assertValue("A2", "#DIV/0!")
        self.assertValue("A3", "#DIV/0!")
        self.assertValue("A4", 1)

    def test_R5_negative_base_integer_vs_fractional_power(self):
        self.put(B1="-8", A1="=B1^2", A2="=B1^-1", A3="=B1^0.5")
        self.assertValue("A1", 64)
        self.assertValue("A2", -0.125)
        self.assertValue("A3", "#NUM!")

    def test_R5_infinite_results_are_num(self):
        self.put(A1="=10^400", A2="=10^200*10^200", A3="=-10^400")
        self.assertValue("A1", "#NUM!")
        self.assertValue("A2", "#NUM!")
        self.assertValue("A3", "#NUM!")

    def test_R7_R8_division_by_empty_cell(self):
        self.put(A1="=5/B1", A2="=B1/5")
        self.assertValue("A1", "#DIV/0!")
        self.assertValue("A2", 0)


class GroupB_R6_Functions(Base):

    def setUp(self):
        super().setUp()
        self.put(A1="1", B1="2", A2="3", B2="4")

    def test_R6_reversed_and_mixed_corner_ranges(self):
        self.put(C1="=SUM(B2:A1)", C2="=SUM(B1:A2)", C3="=MIN(A2:B1)",
                 C4="=AVERAGE(b2:a1)")
        self.assertValue("C1", 10)
        self.assertValue("C2", 10)
        self.assertValue("C3", 1)
        self.assertValue("C4", 2.5)

    def test_R6_single_reference_argument_skips_empty_cell(self):
        self.put(C1="=AVERAGE(D1, B2)", C2="=MIN(D1, B2)", C3="=AVERAGE(D1)")
        self.assertValue("C1", 4)
        self.assertValue("C2", 4)
        self.assertValue("C3", "#DIV/0!")

    def test_R6_R7_parenthesized_or_expression_argument_counts_zero(self):
        self.put(C1="=AVERAGE((D1), B2)", C2="=MIN(D1+0, B2)",
                 C3="=MAX((D1), -1)")
        self.assertValue("C1", 2)
        self.assertValue("C2", 0)
        self.assertValue("C3", 0)

    def test_R6_functions_with_no_values(self):
        self.put(C1="=SUM(D1:E5)", C2="=MIN(D1:E5)", C3="=MAX(D1, D2)",
                 C4="=AVERAGE(D5:D1)")
        self.assertValue("C1", 0)
        self.assertValue("C2", 0)
        self.assertValue("C3", 0)
        self.assertValue("C4", "#DIV/0!")

    def test_R6_max_of_negatives_and_nested_functions(self):
        self.put(C1="=MAX(-5, -3)", C2="=MIN(5, MAX(A1:B2), -1+3)",
                 C3="=SUM(A1:A2, B1:B2, 10)")
        self.assertValue("C1", -3)
        self.assertValue("C2", 2)
        self.assertValue("C3", 20)


class GroupB_R4_Syntax(Base):

    def test_R4_invalid_references(self):
        self.put(A1="=A0", A2="=A100", A3="=AA1", A4="=B01")
        for c in ("A1", "A2", "A3", "A4"):
            self.assertValue(c, "#SYNTAX!")

    def test_R4_unknown_function_and_no_arguments(self):
        self.put(A1="=COUNT(B1:B2)", A2="=SUMS(1)", A3="=SUM()",
                 A4="=MAX(1,)")
        for c in ("A1", "A2", "A3", "A4"):
            self.assertValue(c, "#SYNTAX!")

    def test_R4_range_outside_function_argument(self):
        self.put(A1="=B1:B2", A2="=SUM(B1:B2)+B1:B2", A3="=SUM((B1:B2))",
                 A4="=SUM(B1:B2+1)")
        for c in ("A1", "A2", "A3", "A4"):
            self.assertValue(c, "#SYNTAX!")

    def test_R4_empty_formula_and_unary_plus(self):
        self.put(A1="=", A2="=   ", A3="=+1", A4="=()")
        for c in ("A1", "A2", "A3", "A4"):
            self.assertValue(c, "#SYNTAX!")

    def test_R4_bad_numbers_and_spaces_inside_tokens(self):
        self.put(A1="=.5", A2="=3.", A3="=1e3", A4="=1 2", A5="=B 1",
                 A6="=SU M(1)")
        for c in ("A1", "A2", "A3", "A4", "A5", "A6"):
            self.assertValue(c, "#SYNTAX!")

    def test_R4_letter_case_and_spaces_between_tokens(self):
        self.put(B1="1", B2="2", B3="3",
                 A1="=  sUm ( b1 : B3 )  ", A2="=  Max(b1,B2) * - b3 ",
                 A3="= 007 + 1", A4="=2 - - 1")
        self.assertValue("A1", 6)
        self.assertValue("A2", -6)
        self.assertValue("A3", 8)
        self.assertValue("A4", 3)


class GroupB_R2_Literals(Base):

    def test_R2_valid_number_literal_edge_cases(self):
        self.put(A1="007", A2="-0.25", A3="0.0", A4="-12.500")
        self.assertValue("A1", 7)
        self.assertValue("A2", -0.25)
        self.assertValue("A3", 0)
        self.assertValue("A4", -12.5)

    def test_R2_invalid_number_literals_are_value_errors(self):
        texts = [".5", "3.", "+4", "1e3", "- 3", "--3", "1.2.3", "1_000",
                 "inf", "nan", "1 2", "12abc", "-.5"]
        for i, text in enumerate(texts, start=1):
            self.s.set(f"A{i}", text)
            self.assertValue(f"A{i}", "#VALUE!")

    def test_R2_whitespace_stripping(self):
        self.put(A1="\t5\n", A2=" \n\t ", A3="  =1+1  ", A4="\n=-2^2\t")
        self.assertValue("A1", 5)
        self.assertValue("A2", None)
        self.assertValue("A3", 2)
        self.assertValue("A4", -4)


class GroupB_R7_R10_Recalculation(Base):

    def test_R7_reference_to_empty_cell_is_zero(self):
        self.put(A1="=B1", A2="=2^B1", A3="=B1*3-1")
        self.assertValue("A1", 0)
        self.assertValue("A2", 1)
        self.assertValue("A3", -1)

    def test_R10_clearing_cell_recalculates_chain(self):
        self.put(A1="5", B1="=A1*2", C1="=B1+A1", D1="=AVERAGE(A1)")
        self.assertValue("C1", 15)
        self.s.set("A1", "")
        self.assertValue("A1", None)
        self.assertValue("B1", 0)
        self.assertValue("C1", 0)
        self.assertValue("D1", "#DIV/0!")

    def test_R10_range_and_error_recalculation(self):
        self.put(A1="1", A3="2", B1="=SUM(A1:A3)", C1="=B1*10")
        self.assertValue("C1", 30)
        self.s.set("A2", "bad")
        self.assertValue("C1", "#VALUE!")
        self.s.set("A2", "=A1+A3")
        self.assertValue("C1", 60)

    def test_R10_formula_replaced_by_number(self):
        self.put(A1="=B1+1", B1="=C1", C1="4")
        self.assertValue("A1", 5)
        self.s.set("B1", "10")
        self.s.set("C1", "x")
        self.assertValue("A1", 11)


if __name__ == "__main__":
    unittest.main()
