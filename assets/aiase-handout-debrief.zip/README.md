# Hidden tests

Copy `test_hidden.py` into the same folder as your `sheet.py`, then run:

- macOS / Linux: `python3 -m unittest test_hidden`
- Windows: `py -m unittest test_hidden`

Group A tests check rules R5 and R9. Group B tests check everything else. How many of each did you pass?
