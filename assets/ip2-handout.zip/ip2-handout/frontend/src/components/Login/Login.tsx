import React from 'react';
import PreJoinScreens from '../VideoCall/VideoFrontend/components/PreJoinScreens/PreJoinScreens';

export default function Login(): JSX.Element {
  return (
    <>
      <PreJoinScreens />
    </>
  );
}
