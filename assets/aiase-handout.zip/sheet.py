"""A small spreadsheet engine. See spec.md for the full specification.

Python 3.10+, standard library only.
"""


class Sheet:
    """A spreadsheet with cells A1 through Z99."""

    def __init__(self) -> None:
        """Create a sheet in which every cell is empty."""
        raise NotImplementedError

    def set(self, cell: str, text: str) -> None:
        """Store `text` in `cell`, replacing its previous contents (R2)."""
        raise NotImplementedError

    def get(self, cell: str) -> int | float | str | None:
        """Return the current value of `cell` (R3).

        None if the cell is empty, otherwise a number or an error string
        such as "#DIV/0!" (R8).
        """
        raise NotImplementedError
