"""Public tests for the spreadsheet engine described in spec.md.

Run with:  python3 -m unittest test_public
"""

import math
import unittest

from sheet import Sheet


class PublicTests(unittest.TestCase):

    def setUp(self):
        self.s = Sheet()

    def assertNumber(self, actual, expected):
        """Check that `actual` is a number close to `expected` (see R3)."""
        self.assertNotIsInstance(actual, (str, type(None)),
                                 f"expected a number, got {actual!r}")
        self.assertTrue(
            math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-9),
            f"expected {expected!r}, got {actual!r}")

    # ----- R2 / R3: literals and empty cells -----

    def test_R2_integer_literal(self):
        self.s.set("A1", "42")
        self.assertNumber(self.s.get("A1"), 42)

    def test_R2_negative_decimal_literal(self):
        self.s.set("A1", "-3.5")
        self.assertNumber(self.s.get("A1"), -3.5)

    def test_R2_surrounding_whitespace_is_stripped(self):
        self.s.set("A1", "  7  ")
        self.assertNumber(self.s.get("A1"), 7)

    def test_R3_unset_cell_is_none(self):
        self.assertIsNone(self.s.get("B2"))

    def test_R2_blank_text_makes_cell_empty(self):
        self.s.set("A1", "10")
        self.s.set("A1", "   ")
        self.assertIsNone(self.s.get("A1"))

    def test_R2_other_text_is_value_error(self):
        self.s.set("A1", "hello")
        self.assertEqual(self.s.get("A1"), "#VALUE!")

    # ----- R4 / R5: references and arithmetic -----

    def test_R4_reference_to_another_cell(self):
        self.s.set("A1", "3")
        self.s.set("B1", "=A1")
        self.assertNumber(self.s.get("B1"), 3)

    def test_R5_multiplication_before_addition(self):
        self.s.set("A1", "=2+3*4")
        self.assertNumber(self.s.get("A1"), 14)

    def test_R5_parentheses_override_precedence(self):
        self.s.set("A1", "=(2+3)*4")
        self.assertNumber(self.s.get("A1"), 20)

    def test_R5_subtraction_groups_left_to_right(self):
        self.s.set("A1", "=10-4-3")
        self.assertNumber(self.s.get("A1"), 3)

    def test_R5_division_gives_fraction(self):
        self.s.set("A1", "=7/2")
        self.assertNumber(self.s.get("A1"), 3.5)

    def test_R5_simple_power(self):
        self.s.set("A1", "=2^3")
        self.assertNumber(self.s.get("A1"), 8)

    def test_R5_arithmetic_with_references(self):
        self.s.set("A1", "6")
        self.s.set("A2", "4")
        self.s.set("A3", "= A1 * A2 - A1 / A2")  # 24 - 1.5
        self.assertNumber(self.s.get("A3"), 22.5)

    def test_R7_empty_cell_counts_as_zero(self):
        self.s.set("B1", "=A1+5")
        self.assertNumber(self.s.get("B1"), 5)

    # ----- R6: functions -----

    def test_R6_sum_of_range(self):
        self.s.set("A1", "1")
        self.s.set("A2", "2")
        self.s.set("A3", "3")
        self.s.set("B1", "=SUM(A1:A3)")
        self.assertNumber(self.s.get("B1"), 6)

    def test_R6_min_and_max_of_rectangle(self):
        self.s.set("A1", "4")
        self.s.set("B1", "-2")
        self.s.set("A2", "7")
        self.s.set("B2", "1")
        self.s.set("C1", "=MIN(A1:B2)")
        self.s.set("C2", "=MAX(A1:B2)")
        self.assertNumber(self.s.get("C1"), -2)
        self.assertNumber(self.s.get("C2"), 7)

    def test_R6_average_of_range(self):
        self.s.set("A1", "2")
        self.s.set("A2", "4")
        self.s.set("A3", "9")
        self.s.set("B1", "=AVERAGE(A1:A3)")
        self.assertNumber(self.s.get("B1"), 5)

    def test_R6_range_skips_empty_cells(self):
        self.s.set("A1", "2")
        self.s.set("A3", "4")  # A2 is empty and is not counted
        self.s.set("B1", "=AVERAGE(A1:A3)")
        self.assertNumber(self.s.get("B1"), 3)

    def test_R6_function_with_reference_and_number(self):
        self.s.set("A1", "10")
        self.s.set("A2", "=SUM(A1, 5) * 2")
        self.assertNumber(self.s.get("A2"), 30)

    def test_R4_lowercase_function_and_references(self):
        self.s.set("A1", "1")
        self.s.set("A2", "2")
        self.s.set("B1", "=sum(a1:a2)")
        self.assertNumber(self.s.get("B1"), 3)

    # ----- R10: recalculation -----

    def test_R10_recalculates_after_change(self):
        self.s.set("A1", "10")
        self.s.set("A2", "=SUM(A1, 5) * 2")
        self.s.set("A1", "4")
        self.assertNumber(self.s.get("A2"), 18)

    def test_R10_recalculates_through_chain(self):
        self.s.set("A1", "1")
        self.s.set("B1", "=A1*2")
        self.s.set("C1", "=B1+1")
        self.assertNumber(self.s.get("C1"), 3)
        self.s.set("A1", "5")
        self.assertNumber(self.s.get("C1"), 11)

    # ----- R8: errors -----

    def test_R8_division_by_zero(self):
        self.s.set("A1", "=1/0")
        self.assertEqual(self.s.get("A1"), "#DIV/0!")

    def test_R8_error_in_referenced_cell_propagates(self):
        self.s.set("A1", "hello")
        self.s.set("B1", "=A1+1")
        self.assertEqual(self.s.get("B1"), "#VALUE!")

    def test_R4_incomplete_formula_is_syntax_error(self):
        self.s.set("A1", "=1+")
        self.assertEqual(self.s.get("A1"), "#SYNTAX!")


if __name__ == "__main__":
    unittest.main()
