# Spreadsheet Engine Specification

Implement the class `Sheet` in `sheet.py` using Python 3.10+ and only the standard library. Run the tests with `python -m unittest`.

```python
s = Sheet()
s.set("A1", "10")
s.set("A2", "=SUM(A1, 5) * 2")
s.get("A2")        # 30
s.set("A1", "4")
s.get("A2")        # 18
```

## Cells and values

**R1. Cell names** are a column letter `A`–`Z` followed by a row number `1`–`99` with no leading zeros, e.g. `C7`. `set` and `get` always receive valid, uppercase names.

**R2. `set(cell, text)`** replaces the cell's contents. After stripping leading and trailing whitespace from `text` (as `str.strip()` does):
- if it's empty, the cell becomes **empty**;
- if it starts with `=`, the rest is a **formula** (R4);
- if it's a **number literal**, the cell holds that number. A number literal is an optional `-`, then digits, then optionally `.` and more digits. So `-3.5` and `007` are valid; `.5`, `3.`, `+4` and `1e3` are not;
- otherwise, its value is `#VALUE!`.

**R3. `get(cell)`** returns `None` for an empty cell, otherwise a number or an error string (R8). Tests compare numbers with `math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-9)` and don't check their type.

## Formulas

**R4. Grammar.** A formula must match `expr`, where `*` means "zero or more" and `?` means "optional":

```
expr     = term (("+" | "-") term)*
term     = unary (("*" | "/") unary)*
unary    = "-" unary | power
power    = primary ("^" unary)?
primary  = NUMBER | REF | FUNC "(" arg ("," arg)* ")" | "(" expr ")"
arg      = REF ":" REF | expr
```

`NUMBER` is an R2 number literal without the `-`. `REF` is an R1 cell name. `FUNC` is `SUM`, `MIN`, `MAX` or `AVERAGE`. Letters in `REF` and `FUNC` can be any case. The tokens are `NUMBER`, `REF`, `FUNC` and the symbols `+ - * / ^ ( ) , :`. Spaces are allowed between tokens and around the formula, but not inside a token.

A formula that doesn't match has the value `#SYNTAX!`. That includes references such as `A0`, `A100` or `AA1`, unknown functions, and ranges outside function arguments.

**R5. Arithmetic.** `^` has the highest precedence. It groups right to left and binds more tightly than a unary minus before it, so `2^3^2` = 512 and `-2^2` = −4. Its right operand may start with a minus, so `2^-1` = 0.5. Below that are unary `-`, then `*` and `/`, then `+` and `-`; the last two levels group left to right. There is no unary `+`.

Numbers are Python `float`s. `0^0` is 1. A negative number raised to a non-integer power is `#NUM!`, and so is any other operation whose result is infinite, such as `10^400`.

**R6. Functions.** Each argument contributes values:
- a **range** `X:Y` covers the rectangle with corners `X` and `Y`, given in any order. It contributes each non-empty cell, row by row from the top, left to right;
- an argument that is exactly one cell reference is a one-cell range, so an empty cell contributes nothing;
- any other argument, such as `(A1)` or `A1+0`, is an expression and contributes its value.

`SUM`, `MIN` and `MAX` return the total, smallest and largest value, or 0 if there are no values. `AVERAGE` returns the mean, or `#DIV/0!` if there are no values.

**R7. Empty cells** count as 0 in expressions, except where R6 skips them.

## Errors

**R8. Error values** are `#SYNTAX!` (R4), `#VALUE!` (R2), `#NUM!` (R5), `#CYCLE!` (R9), and `#DIV/0!`. `#DIV/0!` is caused by division by zero, by `0` raised to a negative power, or by R6.

If any operand or argument is an error, including a referenced cell or a cell in a range, the formula's value is an error. Each operator's left operand is fully evaluated before its right operand, whatever the precedence, and function arguments are evaluated left to right, with range cells in R6 order. Except for R9, **the first error found is the result**. For example, if `A1` is `#VALUE!`, then `=A1+1/0` is `#VALUE!` and `=1/0+A1` is `#DIV/0!`.

**R9. Cycles.** A formula cell *depends on* every cell it references, including every cell in its ranges, even empty ones. A formula with a syntax error references nothing. A cell is **in a cycle** if it depends on itself, directly or through other cells.

**Every cell in a cycle, and every cell that depends directly or indirectly on one, has the value `#CYCLE!`**, overriding any other error. For example:

| Cell | Contents | Value |
|---|---|---|
| A1 | `=B1` | `#CYCLE!` |
| B1 | `=A1` | `#CYCLE!` |
| C1 | `=1/0 + A1` | `#CYCLE!` |
| E1 | `=SUM(E2:E5)` | `#CYCLE!` |
| E3 | `=E1` | `#CYCLE!` |

**R10. Recalculation.** `get` always reflects the current contents of every cell, so changing or clearing a cell can create or break a cycle.

## Not tested

- Reference chains longer than 50 cells.
- Running time, as long as each test takes well under a second.
- Number literals with more than 15 digits.
- Floating-point corner cases: rounding error, negative zero, and overflow inside `SUM` or `AVERAGE`.
- Non-ASCII characters, and whitespace other than spaces inside formulas.
