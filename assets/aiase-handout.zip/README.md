# In-class activity: build a spreadsheet engine

You have **10 minutes**. Implement the `Sheet` class in `sheet.py` so that it meets the specification in `spec.md`. Use any AI tool you like.

- Python 3.10 or newer, standard library only. Nothing to install.
- Run the tests from this folder:
  - macOS / Linux: `python3 -m unittest`
  - Windows: `py -m unittest`
- `test_public.py` contains some of the tests. There are more.
